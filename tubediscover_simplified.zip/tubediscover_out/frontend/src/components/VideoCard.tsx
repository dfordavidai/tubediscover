import Link from 'next/link';
import Image from 'next/image';
import { VideoData, formatViews, formatDuration, timeAgo } from '@/lib/api';
import { cn } from '@/lib/utils';

interface VideoCardProps {
  video: VideoData;
  className?: string;
  priority?: boolean;
}

export function VideoCard({ video, className, priority = false }: VideoCardProps) {
  const watchUrl = `/watch/${video.youtubeId}`;
  const duration = formatDuration(video.duration);
  const views = formatViews(video.views);
  const age = timeAgo(video.publishedAt);

  return (
    <article className={cn('group flex flex-col gap-2', className)}>
      {/* Thumbnail */}
      <Link href={watchUrl} className="relative block overflow-hidden rounded-xl bg-[#272727] aspect-video">
        <Image
          src={video.thumbnail || `https://i.ytimg.com/vi/${video.youtubeId}/hqdefault.jpg`}
          alt={video.title || 'Video thumbnail'}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover group-hover:scale-105 transition-transform duration-300"
          priority={priority}
          loading={priority ? 'eager' : 'lazy'}
        />
        {duration && (
          <span className="absolute bottom-2 right-2 bg-black/80 text-white text-xs font-medium px-1.5 py-0.5 rounded">
            {duration}
          </span>
        )}
        {video.hotScore > 50 && (
          <span className="absolute top-2 left-2 bg-[#ff0000] text-white text-xs font-bold px-2 py-0.5 rounded-full">
            🔥 HOT
          </span>
        )}
      </Link>

      {/* Meta */}
      <div className="flex gap-2 px-0.5">
        <Link
          href={video.channel ? `/channel/${video.channel.youtubeChannelId}` : '#'}
          className="shrink-0 mt-0.5"
          aria-label={video.channel?.name}
        >
          <div className="w-9 h-9 rounded-full bg-[#3a3a3a] flex items-center justify-center text-sm font-bold text-[#aaaaaa] hover:bg-[#555] transition-colors">
            {(video.channel?.name || 'C')[0].toUpperCase()}
          </div>
        </Link>

        <div className="flex-1 min-w-0">
          <Link href={watchUrl}>
            <h3 className="text-sm font-medium leading-snug line-clamp-2 group-hover:text-[#3ea6ff] transition-colors">
              {video.title || 'Untitled video'}
            </h3>
          </Link>
          {video.channel && (
            <Link href={`/channel/${video.channel.youtubeChannelId}`} className="text-xs text-[#aaaaaa] hover:text-[#f1f1f1] transition-colors mt-0.5 block truncate">
              {video.channel.name}
            </Link>
          )}
          <p className="text-xs text-[#717171] mt-0.5">
            {views && `${views} views`}
            {views && age && ' · '}
            {age}
          </p>
        </div>
      </div>
    </article>
  );
}

export function VideoCardSkeleton() {
  return (
    <div className="flex flex-col gap-2">
      <div className="skeleton aspect-video rounded-xl" />
      <div className="flex gap-2 px-0.5">
        <div className="skeleton w-9 h-9 rounded-full shrink-0" />
        <div className="flex-1 space-y-2">
          <div className="skeleton h-4 rounded w-full" />
          <div className="skeleton h-3 rounded w-3/4" />
          <div className="skeleton h-3 rounded w-1/2" />
        </div>
      </div>
    </div>
  );
}
