'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Search, Menu, X, TrendingUp, Play } from 'lucide-react';
import { api } from '@/lib/api';
import { cn } from '@/lib/utils';

export function Header() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [query, setQuery] = useState(searchParams?.get('q') || '');
  const [suggestions, setSuggestions] = useState<Array<{ title: string; id: string; slug: string }>>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<NodeJS.Timeout>();

  const fetchSuggestions = useCallback(async (q: string) => {
    if (q.length < 2) { setSuggestions([]); return; }
    try {
      const res = await api.suggest(q);
      setSuggestions(res.suggestions.slice(0, 8));
    } catch { setSuggestions([]); }
  }, []);

  useEffect(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => fetchSuggestions(query), 300);
    return () => clearTimeout(debounceRef.current);
  }, [query, fetchSuggestions]);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (suggestRef.current && !suggestRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;
    setShowSuggestions(false);
    router.push(`/search/${encodeURIComponent(query.trim())}`);
  }

  const NAV_LINKS = [
    { href: '/trending', label: 'Trending', icon: <TrendingUp size={16} /> },
    { href: '/category/music', label: 'Music' },
    { href: '/category/sports', label: 'Sports' },
    { href: '/category/gaming', label: 'Gaming' },
    { href: '/category/news', label: 'News' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#0f0f0f]/95 backdrop-blur-sm border-b border-[#3a3a3a]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center gap-4 h-14">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0 group">
            <div className="w-8 h-8 bg-[#ff0000] rounded-lg flex items-center justify-center group-hover:bg-[#cc0000] transition-colors">
              <Play size={16} fill="white" className="text-white ml-0.5" />
            </div>
            <span className="font-bold text-lg hidden sm:block">
              Tube<span className="text-[#ff0000]">Discover</span>
            </span>
          </Link>

          {/* Search */}
          <div className="flex-1 max-w-2xl relative" ref={suggestRef}>
            <form onSubmit={handleSearch} className="flex">
              <input
                ref={inputRef}
                type="search"
                value={query}
                onChange={(e) => { setQuery(e.target.value); setShowSuggestions(true); }}
                onFocus={() => setShowSuggestions(true)}
                placeholder="Search videos..."
                className={cn(
                  'w-full bg-[#121212] border border-[#3a3a3a] rounded-l-full px-5 py-2 text-sm',
                  'focus:outline-none focus:border-[#3ea6ff] transition-colors',
                  'placeholder:text-[#717171]'
                )}
              />
              <button
                type="submit"
                className="bg-[#272727] border border-l-0 border-[#3a3a3a] px-5 rounded-r-full hover:bg-[#3a3a3a] transition-colors"
                aria-label="Search"
              >
                <Search size={18} className="text-[#aaaaaa]" />
              </button>
            </form>

            {/* Suggestions dropdown */}
            {showSuggestions && suggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-[#212121] border border-[#3a3a3a] rounded-xl shadow-xl overflow-hidden z-50">
                {suggestions.map((s) => (
                  <button
                    key={s.id}
                    className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[#3a3a3a] text-left text-sm transition-colors"
                    onClick={() => {
                      setQuery(s.title);
                      setShowSuggestions(false);
                      router.push(`/watch/${s.id}`);
                    }}
                  >
                    <Search size={14} className="text-[#717171] shrink-0" />
                    <span className="truncate">{s.title}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm text-[#aaaaaa] hover:text-[#f1f1f1] hover:bg-[#272727] transition-colors"
              >
                {link.icon}
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Mobile menu toggle */}
          <button
            className="lg:hidden p-2 rounded-full hover:bg-[#272727] transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Menu"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile nav */}
        {mobileMenuOpen && (
          <nav className="lg:hidden py-3 border-t border-[#3a3a3a] flex flex-wrap gap-2 pb-4">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full text-sm bg-[#272727] hover:bg-[#3a3a3a] transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.icon}
                {link.label}
              </Link>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
