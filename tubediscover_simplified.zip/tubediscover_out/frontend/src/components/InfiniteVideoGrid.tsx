'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { VideoCard, VideoCardSkeleton } from './VideoCard';
import { VideoData } from '@/lib/api';

interface InfiniteVideoGridProps {
  initialVideos: VideoData[];
  loadMore?: (page: number) => Promise<VideoData[]>;
  hasMore?: boolean;
}

export function InfiniteVideoGrid({ initialVideos, loadMore, hasMore: initialHasMore = true }: InfiniteVideoGridProps) {
  const [videos, setVideos] = useState<VideoData[]>(initialVideos);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(initialHasMore && !!loadMore);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);

  const loadNextPage = useCallback(async () => {
    if (!loadMore || loading || !hasMore) return;
    setLoading(true);
    try {
      const nextPage = page + 1;
      const newVideos = await loadMore(nextPage);
      if (newVideos.length === 0) {
        setHasMore(false);
      } else {
        setVideos((prev) => {
          const ids = new Set(prev.map((v) => v.youtubeId));
          return [...prev, ...newVideos.filter((v) => !ids.has(v.youtubeId))];
        });
        setPage(nextPage);
      }
    } catch (err) {
      console.error('Failed to load more videos', err);
    } finally {
      setLoading(false);
    }
  }, [loadMore, loading, hasMore, page]);

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    observerRef.current = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          loadNextPage();
        }
      },
      { rootMargin: '400px' }
    );
    observerRef.current.observe(sentinel);
    return () => observerRef.current?.disconnect();
  }, [loadNextPage, hasMore, loading]);

  if (videos.length === 0 && !loading) {
    return (
      <div className="text-center py-20 text-[#717171]">
        <p className="text-lg">No videos found yet.</p>
        <p className="text-sm mt-2">Check back soon — we're discovering new content!</p>
      </div>
    );
  }

  return (
    <div>
      <div className="video-grid">
        {videos.map((video, i) => (
          <VideoCard key={video.youtubeId} video={video} priority={i < 4} />
        ))}
        {loading && Array.from({ length: 8 }).map((_, i) => <VideoCardSkeleton key={`sk-${i}`} />)}
      </div>

      <div ref={sentinelRef} className="h-4" aria-hidden="true" />

      {!hasMore && videos.length > 0 && (
        <p className="text-center text-[#717171] text-sm py-8">You've reached the end</p>
      )}
    </div>
  );
}
