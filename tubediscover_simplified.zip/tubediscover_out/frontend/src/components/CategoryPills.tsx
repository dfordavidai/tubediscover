'use client';

import Link from 'next/link';
import { cn } from '@/lib/utils';

const CATEGORIES = [
  { label: 'All', href: '/' },
  { label: 'Trending', href: '/trending' },
  { label: 'Music', href: '/category/music' },
  { label: 'Sports', href: '/category/sports' },
  { label: 'Gaming', href: '/category/gaming' },
  { label: 'News', href: '/category/news' },
  { label: 'Entertainment', href: '/category/entertainment' },
  { label: 'Tech', href: '/category/tech' },
  { label: 'Education', href: '/category/education' },
  { label: 'Lifestyle', href: '/category/lifestyle' },
];

interface CategoryPillsProps {
  active?: string;
}

export function CategoryPills({ active }: CategoryPillsProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide -mx-4 px-4 sm:mx-0 sm:px-0">
      {CATEGORIES.map((cat) => {
        const isActive = active
          ? cat.label.toLowerCase() === active.toLowerCase()
          : cat.href === '/';
        return (
          <Link
            key={cat.href}
            href={cat.href}
            className={cn(
              'category-pill shrink-0',
              isActive && 'category-pill-active'
            )}
          >
            {cat.label}
          </Link>
        );
      })}
    </div>
  );
}
