const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

export interface VideoData {
  youtubeId: string;
  title: string;
  slug: string;
  description: string;
  thumbnail: string;
  duration: number | null;
  channel: { id: string; name: string; slug: string; youtubeChannelId: string } | null;
  views: string;
  likes: string;
  category: string;
  tags: string[];
  language: string;
  hotScore: number;
  publishedAt: string | null;
  aiSummary: string;
  indexedAt: string;
}

export interface SearchResult {
  hits: VideoData[];
  total: number;
  page: number;
  pages: number;
  aiIntro: string;
  relatedKeywords: string[];
}

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options?.headers },
  });
  if (!res.ok) throw new Error(`API error ${res.status}: ${path}`);
  return res.json();
}

export const api = {
  trending: (category?: string, limit = 24): Promise<{ videos: VideoData[] }> =>
    apiFetch(`/api/videos/trending?limit=${limit}${category ? `&category=${category}` : ''}`),

  recent: (limit = 24): Promise<{ videos: VideoData[] }> =>
    apiFetch(`/api/videos/recent?limit=${limit}`),

  video: (id: string): Promise<{ video: VideoData }> =>
    apiFetch(`/api/videos/${id}`),

  related: (id: string): Promise<{ videos: VideoData[] }> =>
    apiFetch(`/api/videos/${id}/related`),

  search: (q: string, page = 1, category?: string, sort = 'relevance'): Promise<SearchResult> =>
    apiFetch(`/api/search?q=${encodeURIComponent(q)}&page=${page}&sort=${sort}${category ? `&category=${category}` : ''}`),

  suggest: (q: string): Promise<{ suggestions: Array<{ title: string; id: string; slug: string }> }> =>
    apiFetch(`/api/search/suggest?q=${encodeURIComponent(q)}`),

  stats: (): Promise<{ videoCount: number; channelCount: number; keywordCount: number }> =>
    apiFetch('/api/stats'),
};

export function formatViews(views: string | number): string {
  const n = typeof views === 'string' ? parseInt(views) : views;
  if (isNaN(n)) return '0';
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(1)}B`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

export function formatDuration(seconds: number | null): string {
  if (!seconds) return '';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function timeAgo(dateStr: string | null): string {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(mins / 60);
  const days = Math.floor(hours / 24);
  const months = Math.floor(days / 30);
  const years = Math.floor(months / 12);
  if (years > 0) return `${years}y ago`;
  if (months > 0) return `${months}mo ago`;
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (mins > 0) return `${mins}m ago`;
  return 'just now';
}
