import { NextResponse } from 'next/server';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

export const revalidate = 3600; // regenerate every hour

export async function GET() {
  // Fetch chunk metadata from backend
  let videoChunks: { chunkNum: number }[] = [];
  let searchChunks: { chunkNum: number }[] = [];

  try {
    const res = await fetch(`${API_URL}/api/sitemap/chunks`, { next: { revalidate: 3600 } });
    if (res.ok) {
      const data = await res.json();
      videoChunks = data.chunks.filter((c: { type: string }) => c.type === 'video');
      searchChunks = data.chunks.filter((c: { type: string }) => c.type === 'search');
    }
  } catch {
    // fallback: assume at least 1 chunk exists
    videoChunks = [{ chunkNum: 0 }];
  }

  // Always include at least chunk 0
  if (videoChunks.length === 0) videoChunks = [{ chunkNum: 0 }];

  const staticSitemaps = [
    `${SITE_URL}/sitemaps/static.xml`,
    ...videoChunks.map((c) => `${SITE_URL}/sitemaps/videos-${c.chunkNum}.xml`),
    ...searchChunks.map((c) => `${SITE_URL}/sitemaps/searches-${c.chunkNum}.xml`),
  ];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${staticSitemaps
  .map(
    (loc) => `  <sitemap>
    <loc>${loc}</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
  </sitemap>`
  )
  .join('\n')}
</sitemapindex>`;

  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600, s-maxage=3600',
    },
  });
}
