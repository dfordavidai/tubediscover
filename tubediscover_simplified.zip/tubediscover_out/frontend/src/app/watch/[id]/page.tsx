import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { api, VideoData, formatViews, timeAgo } from '@/lib/api';
import { VideoCard } from '@/components/VideoCard';
import { ThumbsUp, Share2, ExternalLink } from 'lucide-react';

export const revalidate = 86400; // 24 hours

interface Props {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  try {
    const { video } = await api.video(id);
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';

    return {
      title: video.title || 'Watch Video',
      description: video.aiSummary || video.description?.slice(0, 160) || `Watch ${video.title} on TubeDiscover.`,
      keywords: video.tags?.join(', '),
      openGraph: {
        title: video.title || '',
        description: video.aiSummary || video.description?.slice(0, 160) || '',
        type: 'video.other',
        videos: [`https://www.youtube.com/watch?v=${video.youtubeId}`],
        images: [{ url: video.thumbnail || '', width: 1280, height: 720, alt: video.title || '' }],
        url: `${siteUrl}/watch/${video.youtubeId}`,
      },
      twitter: {
        card: 'summary_large_image',
        title: video.title || '',
        description: video.aiSummary || video.description?.slice(0, 160) || '',
        images: [video.thumbnail || ''],
      },
      alternates: { canonical: `${siteUrl}/watch/${video.youtubeId}` },
    };
  } catch {
    return { title: 'Video Not Found' };
  }
}

function VideoJsonLd({ video }: { video: VideoData }) {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'VideoObject',
    name: video.title,
    description: video.aiSummary || video.description,
    thumbnailUrl: video.thumbnail,
    uploadDate: video.publishedAt,
    duration: video.duration ? `PT${Math.floor(video.duration / 60)}M${video.duration % 60}S` : undefined,
    contentUrl: `https://www.youtube.com/watch?v=${video.youtubeId}`,
    embedUrl: `https://www.youtube.com/embed/${video.youtubeId}`,
    url: `${siteUrl}/watch/${video.youtubeId}`,
    author: video.channel ? { '@type': 'Person', name: video.channel.name } : undefined,
    interactionStatistic: [
      { '@type': 'InteractionCounter', interactionType: 'https://schema.org/WatchAction', userInteractionCount: video.views },
      { '@type': 'InteractionCounter', interactionType: 'https://schema.org/LikeAction', userInteractionCount: video.likes },
    ],
    keywords: video.tags?.join(', '),
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />;
}

export default async function WatchPage({ params }: Props) {
  const { id } = await params;

  let video: VideoData;
  let relatedVideos: VideoData[] = [];

  try {
    const [videoRes, relatedRes] = await Promise.allSettled([
      api.video(id),
      api.related(id),
    ]);
    if (videoRes.status === 'rejected') notFound();
    video = (videoRes as PromiseFulfilledResult<{ video: VideoData }>).value.video;
    relatedVideos = relatedRes.status === 'fulfilled' ? relatedRes.value.videos : [];
  } catch {
    notFound();
  }

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';

  return (
    <>
      <VideoJsonLd video={video} />

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Main content */}
          <div className="flex-1 min-w-0">
            {/* Player */}
            <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden">
              <iframe
                src={`https://www.youtube.com/embed/${video.youtubeId}?autoplay=1&rel=0&modestbranding=1`}
                title={video.title || 'Video'}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                className="absolute inset-0 w-full h-full"
                loading="lazy"
              />
            </div>

            {/* Video info */}
            <div className="mt-4">
              <h1 className="text-lg sm:text-xl font-semibold leading-snug">{video.title}</h1>

              <div className="flex flex-wrap items-center justify-between gap-4 mt-3">
                <div className="flex items-center gap-3">
                  {video.channel && (
                    <Link href={`/channel/${video.channel.youtubeChannelId}`} className="flex items-center gap-2 group">
                      <div className="w-10 h-10 rounded-full bg-[#3a3a3a] flex items-center justify-center font-bold group-hover:bg-[#555] transition-colors">
                        {video.channel.name[0]?.toUpperCase()}
                      </div>
                      <span className="font-medium text-sm hover:text-[#3ea6ff] transition-colors">
                        {video.channel.name}
                      </span>
                    </Link>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`https://www.youtube.com/watch?v=${video.youtubeId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 bg-[#272727] hover:bg-[#3a3a3a] rounded-full text-sm transition-colors"
                  >
                    <ExternalLink size={14} />
                    YouTube
                  </a>
                  <button className="flex items-center gap-2 px-4 py-2 bg-[#272727] hover:bg-[#3a3a3a] rounded-full text-sm transition-colors">
                    <Share2 size={14} />
                    Share
                  </button>
                  {video.likes !== '0' && (
                    <span className="flex items-center gap-1.5 px-4 py-2 bg-[#272727] rounded-full text-sm">
                      <ThumbsUp size={14} />
                      {formatViews(video.likes)}
                    </span>
                  )}
                </div>
              </div>

              {/* Stats bar */}
              <div className="flex items-center gap-4 text-sm text-[#717171] mt-3 pb-4 border-b border-[#3a3a3a]">
                {video.views !== '0' && <span>{formatViews(video.views)} views</span>}
                {video.publishedAt && <span>{timeAgo(video.publishedAt)}</span>}
                {video.category && (
                  <Link href={`/category/${video.category.toLowerCase()}`} className="hover:text-[#f1f1f1] transition-colors capitalize">
                    {video.category}
                  </Link>
                )}
              </div>

              {/* AI Summary */}
              {video.aiSummary && (
                <div className="mt-4 p-4 bg-[#1e1e1e] rounded-xl">
                  <h2 className="text-sm font-medium text-[#aaaaaa] mb-2">About this video</h2>
                  <p className="text-sm text-[#f1f1f1] leading-relaxed">{video.aiSummary}</p>
                </div>
              )}

              {/* Description */}
              {video.description && !video.aiSummary && (
                <div className="mt-4 p-4 bg-[#1e1e1e] rounded-xl">
                  <p className="text-sm text-[#aaaaaa] leading-relaxed line-clamp-4">{video.description}</p>
                </div>
              )}

              {/* Tags */}
              {video.tags && video.tags.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {video.tags.slice(0, 12).map((tag) => (
                    <Link
                      key={tag}
                      href={`/search/${encodeURIComponent(tag)}`}
                      className="text-xs px-3 py-1.5 bg-[#1e1e1e] border border-[#3a3a3a] rounded-full hover:bg-[#272727] transition-colors text-[#3ea6ff]"
                    >
                      #{tag}
                    </Link>
                  ))}
                </div>
              )}

              {/* Internal links */}
              <div className="mt-6 pt-4 border-t border-[#3a3a3a]">
                <h3 className="text-sm font-medium text-[#aaaaaa] mb-3">Explore more</h3>
                <div className="flex flex-wrap gap-2">
                  <a href="/trending" className="text-sm text-[#3ea6ff] hover:underline">Trending videos</a>
                  <span className="text-[#3a3a3a]">·</span>
                  {video.category && <a href={`/category/${video.category.toLowerCase()}`} className="text-sm text-[#3ea6ff] hover:underline capitalize">{video.category}</a>}
                  <span className="text-[#3a3a3a]">·</span>
                  <a href={`/search/${encodeURIComponent(video.title?.split(' ').slice(0, 3).join(' ') || '')}`} className="text-sm text-[#3ea6ff] hover:underline">Similar videos</a>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Related videos */}
          <aside className="lg:w-96 shrink-0">
            <h2 className="font-medium mb-4 text-sm text-[#aaaaaa]">Related Videos</h2>
            <div className="space-y-3">
              {relatedVideos.length === 0 ? (
                <p className="text-sm text-[#717171]">Loading related videos...</p>
              ) : (
                relatedVideos.map((rv) => (
                  <RelatedVideoRow key={rv.youtubeId} video={rv} />
                ))
              )}
            </div>

            {/* Category suggestions */}
            <div className="mt-6 pt-4 border-t border-[#3a3a3a]">
              <h3 className="text-sm font-medium text-[#aaaaaa] mb-3">Browse Categories</h3>
              <div className="flex flex-wrap gap-2">
                {['music', 'sports', 'gaming', 'news', 'entertainment'].map((c) => (
                  <a key={c} href={`/category/${c}`} className="text-xs px-3 py-1.5 bg-[#1e1e1e] border border-[#3a3a3a] rounded-full hover:bg-[#272727] transition-colors capitalize">
                    {c}
                  </a>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </>
  );
}

function RelatedVideoRow({ video }: { video: VideoData }) {
  return (
    <Link href={`/watch/${video.youtubeId}`} className="flex gap-2 group">
      <div className="relative w-40 shrink-0 aspect-video rounded-lg overflow-hidden bg-[#272727]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={video.thumbnail}
          alt={video.title || ''}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
          loading="lazy"
        />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium line-clamp-2 group-hover:text-[#3ea6ff] transition-colors leading-snug">
          {video.title}
        </p>
        <p className="text-xs text-[#717171] mt-1 truncate">{video.channel?.name}</p>
        <p className="text-xs text-[#717171]">{formatViews(video.views)} views</p>
      </div>
    </Link>
  );
}
