import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Header } from '@/components/Header';

const inter = Inter({ subsets: ['latin'], display: 'swap' });

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';
const SITE_NAME = 'TubeDiscover';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: `${SITE_NAME} — Discover Videos`,
    template: `%s | ${SITE_NAME}`,
  },
  description: 'Discover trending, viral, and hidden YouTube videos. Search millions of videos across all categories.',
  keywords: ['youtube', 'videos', 'discover', 'trending', 'search', 'watch'],
  authors: [{ name: SITE_NAME }],
  creator: SITE_NAME,
  publisher: SITE_NAME,
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-video-preview': -1, 'max-image-preview': 'large' },
  },
  openGraph: {
    type: 'website',
    siteName: SITE_NAME,
    locale: 'en_US',
  },
  twitter: {
    card: 'summary_large_image',
    site: '@tubediscover',
  },
  verification: {
    google: process.env.GOOGLE_SITE_VERIFICATION || '',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className={`${inter.className} bg-[#0f0f0f] text-[#f1f1f1] min-h-screen antialiased`}>
        <Header />
        <main className="min-h-[calc(100vh-56px)]">{children}</main>
        <footer className="border-t border-[#3a3a3a] py-8 mt-12">
          <div className="max-w-7xl mx-auto px-4 text-center text-[#717171] text-sm">
            <p>© {new Date().getFullYear()} TubeDiscover — Powered by YouTube embeds. We do not host any video content.</p>
            <div className="flex justify-center gap-6 mt-3 flex-wrap">
              <a href="/sitemap.xml" className="hover:text-[#f1f1f1] transition-colors">Sitemap</a>
              <a href="/trending" className="hover:text-[#f1f1f1] transition-colors">Trending</a>
              <a href="/category/music" className="hover:text-[#f1f1f1] transition-colors">Music</a>
              <a href="/category/sports" className="hover:text-[#f1f1f1] transition-colors">Sports</a>
              <a href="/category/gaming" className="hover:text-[#f1f1f1] transition-colors">Gaming</a>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
