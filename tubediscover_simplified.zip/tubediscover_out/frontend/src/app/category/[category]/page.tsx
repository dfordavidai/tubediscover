import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { api } from '@/lib/api';
import { VideoCard } from '@/components/VideoCard';
import { CategoryPills } from '@/components/CategoryPills';

export const revalidate = 3600;

const VALID_CATEGORIES = ['music', 'sports', 'entertainment', 'gaming', 'news', 'tech', 'education', 'lifestyle', 'general'];

const CATEGORY_META: Record<string, { title: string; description: string; icon: string }> = {
  music: { title: 'Music Videos', description: 'Discover the latest music videos, live performances, and artist channels.', icon: '🎵' },
  sports: { title: 'Sports Videos', description: 'Watch match highlights, player skills, and sports analysis.', icon: '⚽' },
  entertainment: { title: 'Entertainment', description: 'Movies, trailers, celebrity news, and viral entertainment videos.', icon: '🎬' },
  gaming: { title: 'Gaming Videos', description: 'Gameplay, game reviews, walkthroughs, and gaming news.', icon: '🎮' },
  news: { title: 'News & Current Events', description: 'Stay updated with breaking news and world events.', icon: '📰' },
  tech: { title: 'Technology', description: 'Tech reviews, tutorials, AI developments, and gadget unboxings.', icon: '💻' },
  education: { title: 'Educational Videos', description: 'Learn something new — documentaries, tutorials, and explainers.', icon: '📚' },
  lifestyle: { title: 'Lifestyle', description: 'Travel vlogs, cooking, fitness, and lifestyle content.', icon: '🌟' },
  general: { title: 'General', description: 'Discover all types of videos.', icon: '📺' },
};

interface Props {
  params: Promise<{ category: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { category } = await params;
  if (!VALID_CATEGORIES.includes(category)) return { title: 'Not Found' };
  const meta = CATEGORY_META[category];
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';
  return {
    title: `${meta.title} — Watch & Discover`,
    description: meta.description,
    keywords: [category, `${category} videos`, `watch ${category}`, `best ${category} videos`],
    openGraph: { title: `${meta.title} on TubeDiscover`, description: meta.description, url: `${siteUrl}/category/${category}` },
    alternates: { canonical: `${siteUrl}/category/${category}` },
  };
}

export async function generateStaticParams() {
  return VALID_CATEGORIES.map((category) => ({ category }));
}

export default async function CategoryPage({ params }: Props) {
  const { category } = await params;
  if (!VALID_CATEGORIES.includes(category)) notFound();
  const meta = CATEGORY_META[category];
  const { videos } = await api.trending(category, 48).catch(() => ({ videos: [] }));

  const searches: Record<string, string[]> = {
    music: ['new music video', 'top hits', 'live performance', 'official music video', 'remix', 'playlist'],
    sports: ['match highlights', 'best goals', 'game recap', 'player skills', 'top 10 plays', 'sports news'],
    gaming: ['gameplay walkthrough', 'game review', 'best games 2024', 'speedrun', 'gaming news', 'tips and tricks'],
    entertainment: ['movie trailer', 'funny videos', 'viral moments', 'celebrity interview', 'reaction video'],
    news: ['breaking news', 'world news today', 'political news', 'news analysis', 'documentary'],
    tech: ['phone review', 'tech news', 'how to', 'AI tutorial', 'gadget unboxing', 'programming tutorial'],
    education: ['learn python', 'history documentary', 'science explained', 'math tutorial', 'language learning'],
    lifestyle: ['travel vlog', 'cooking recipes', 'fitness workout', 'home decor', 'fashion haul'],
    general: ['trending', 'viral', 'funny', 'how to', 'review'],
  };
  const categorySearches = searches[category] || searches.general;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="mb-6"><CategoryPills active={category} /></div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold flex items-center gap-3">
          <span className="text-3xl">{meta.icon}</span>
          {meta.title}
        </h1>
        <p className="text-[#aaaaaa] mt-2 text-sm">{meta.description}</p>
      </div>
      {videos.length === 0 ? (
        <div className="text-center py-20 text-[#717171]">
          <p className="text-4xl mb-4">{meta.icon}</p>
          <p className="text-lg">No {category} videos indexed yet.</p>
          <p className="text-sm mt-2">Our crawlers are working on it!</p>
        </div>
      ) : (
        <div className="video-grid">
          {videos.map((v, i) => <VideoCard key={v.youtubeId} video={v} priority={i < 8} />)}
        </div>
      )}
      <section className="mt-10 pt-6 border-t border-[#3a3a3a]">
        <h2 className="text-sm font-medium text-[#aaaaaa] mb-3">Other categories</h2>
        <div className="flex flex-wrap gap-2">
          {VALID_CATEGORIES.filter((c) => c !== category && c !== 'general').map((cat) => (
            <a key={cat} href={`/category/${cat}`} className="px-4 py-2 bg-[#1e1e1e] border border-[#3a3a3a] rounded-full text-sm hover:bg-[#272727] transition-colors capitalize">
              {CATEGORY_META[cat]?.icon} {cat}
            </a>
          ))}
        </div>
      </section>
      <section className="mt-6">
        <h2 className="text-sm font-medium text-[#aaaaaa] mb-3">Popular {category} searches</h2>
        <div className="flex flex-wrap gap-2">
          {categorySearches.map((kw) => (
            <a key={kw} href={`/search/${encodeURIComponent(kw)}`} className="px-3 py-1.5 bg-[#1e1e1e] border border-[#3a3a3a] rounded-full text-xs hover:bg-[#272727] transition-colors text-[#3ea6ff]">
              {kw}
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}
