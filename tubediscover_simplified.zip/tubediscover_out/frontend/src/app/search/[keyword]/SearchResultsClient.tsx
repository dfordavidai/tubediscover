'use client';

import { api, VideoData } from '@/lib/api';
import { InfiniteVideoGrid } from '@/components/InfiniteVideoGrid';

interface Props {
  keyword: string;
  initialVideos: VideoData[];
  totalPages: number;
}

export function SearchResultsClient({ keyword, initialVideos, totalPages }: Props) {
  const loadMore = async (page: number): Promise<VideoData[]> => {
    if (page > totalPages) return [];
    try {
      const res = await api.search(keyword, page);
      return res.hits;
    } catch {
      return [];
    }
  };

  return (
    <InfiniteVideoGrid
      initialVideos={initialVideos}
      loadMore={totalPages > 1 ? loadMore : undefined}
      hasMore={totalPages > 1}
    />
  );
}
