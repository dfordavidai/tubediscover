import type { Metadata } from 'next';
import { api, VideoData } from '@/lib/api';
import { VideoCard } from '@/components/VideoCard';
import { SearchResultsClient } from './SearchResultsClient';

export const revalidate = 3600; // 1 hour

interface Props {
  params: Promise<{ keyword: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { keyword } = await params;
  const decoded = decodeURIComponent(keyword);
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';

  return {
    title: `${decoded} — Video Search Results`,
    description: `Discover the best YouTube videos about "${decoded}". Watch trending, viral, and popular ${decoded} videos.`,
    keywords: [decoded, `${decoded} videos`, `${decoded} youtube`, `watch ${decoded}`],
    openGraph: {
      title: `${decoded} Videos`,
      description: `Find and watch the best "${decoded}" videos on TubeDiscover.`,
      url: `${siteUrl}/search/${keyword}`,
    },
    alternates: { canonical: `${siteUrl}/search/${encodeURIComponent(decoded)}` },
    robots: { index: true, follow: true },
  };
}

export default async function SearchPage({ params }: Props) {
  const { keyword } = await params;
  const decoded = decodeURIComponent(keyword);
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';

  let initialData = { hits: [] as VideoData[], total: 0, pages: 0, aiIntro: '', relatedKeywords: [] as string[] };

  try {
    const res = await api.search(decoded, 1);
    initialData = res;
  } catch {
    // Return empty state — client can retry
  }

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SearchResultsPage',
    name: `${decoded} — TubeDiscover`,
    url: `${siteUrl}/search/${encodeURIComponent(decoded)}`,
    description: `Search results for "${decoded}"`,
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold">
            Results for <span className="text-[#3ea6ff]">"{decoded}"</span>
          </h1>
          {initialData.total > 0 && (
            <p className="text-sm text-[#717171] mt-1">{initialData.total.toLocaleString()} videos found</p>
          )}
        </div>

        {/* AI Intro */}
        {initialData.aiIntro && (
          <div className="mb-6 p-4 bg-[#1e1e1e] border border-[#3a3a3a] rounded-xl text-sm text-[#aaaaaa] leading-relaxed">
            {initialData.aiIntro}
          </div>
        )}

        {/* Related keywords */}
        {initialData.relatedKeywords.length > 0 && (
          <div className="mb-6">
            <p className="text-sm text-[#717171] mb-2">Related searches:</p>
            <div className="flex flex-wrap gap-2">
              {initialData.relatedKeywords.map((kw) => (
                <a
                  key={kw}
                  href={`/search/${encodeURIComponent(kw)}`}
                  className="px-3 py-1.5 bg-[#1e1e1e] border border-[#3a3a3a] rounded-full text-sm hover:bg-[#272727] transition-colors text-[#3ea6ff]"
                >
                  {kw}
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Results - client handles infinite scroll */}
        <SearchResultsClient
          keyword={decoded}
          initialVideos={initialData.hits}
          totalPages={initialData.pages}
        />

        {/* Internal linking section */}
        <section className="mt-10 pt-6 border-t border-[#3a3a3a]">
          <h2 className="text-sm font-medium text-[#aaaaaa] mb-3">Explore categories</h2>
          <div className="flex flex-wrap gap-2">
            {['music', 'sports', 'gaming', 'entertainment', 'news', 'tech'].map((cat) => (
              <a key={cat} href={`/category/${cat}`} className="px-3 py-1.5 bg-[#1e1e1e] border border-[#3a3a3a] rounded-full text-sm hover:bg-[#272727] transition-colors capitalize">
                {cat}
              </a>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}
