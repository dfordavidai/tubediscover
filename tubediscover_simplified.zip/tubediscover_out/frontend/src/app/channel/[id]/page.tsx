import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { VideoCard, VideoCardSkeleton } from '@/components/VideoCard';
import { VideoData } from '@/lib/api';

export const revalidate = 3600;

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';

interface ChannelData {
  id: string;
  youtubeChannelId: string;
  name: string;
  slug: string;
  logo: string | null;
  subscribers: string;
  indexedAt: string;
}

async function getChannelData(id: string): Promise<{ channel: ChannelData; videos: VideoData[] } | null> {
  try {
    const res = await fetch(`${API_URL}/api/channels/${id}`, { next: { revalidate: 3600 } });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

interface Props {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const data = await getChannelData(id);
  if (!data) return { title: 'Channel Not Found' };

  const { channel } = data;
  return {
    title: `${channel.name} — Videos & Channel`,
    description: `Watch all videos from ${channel.name} on TubeDiscover. Browse the latest uploads and popular content.`,
    openGraph: {
      title: `${channel.name} on TubeDiscover`,
      description: `Discover videos from ${channel.name}`,
      url: `${SITE_URL}/channel/${id}`,
      images: channel.logo ? [{ url: channel.logo }] : [],
    },
    alternates: { canonical: `${SITE_URL}/channel/${id}` },
  };
}

export default async function ChannelPage({ params }: Props) {
  const { id } = await params;
  const data = await getChannelData(id);

  if (!data) notFound();

  const { channel, videos } = data;

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ProfilePage',
    name: channel.name,
    url: `${SITE_URL}/channel/${id}`,
    mainEntity: {
      '@type': 'Person',
      name: channel.name,
      url: `https://www.youtube.com/channel/${channel.youtubeChannelId}`,
    },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Channel header */}
        <div className="flex items-center gap-4 mb-8 pb-6 border-b border-[#3a3a3a]">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#3a3a3a] flex items-center justify-center text-2xl sm:text-3xl font-bold text-[#aaaaaa] shrink-0 overflow-hidden">
            {channel.logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={channel.logo} alt={channel.name} className="w-full h-full object-cover" />
            ) : (
              (channel.name?.[0] || 'C').toUpperCase()
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl sm:text-2xl font-bold truncate">{channel.name}</h1>
            <p className="text-sm text-[#717171] mt-1">
              {videos.length} videos indexed
            </p>
            <a
              href={`https://www.youtube.com/channel/${channel.youtubeChannelId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 mt-2 text-xs text-[#3ea6ff] hover:underline"
            >
              View on YouTube →
            </a>
          </div>
        </div>

        {/* Videos */}
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-semibold text-lg">Videos</h2>
          <span className="text-sm text-[#717171]">{videos.length} found</span>
        </div>

        {videos.length === 0 ? (
          <div className="text-center py-20 text-[#717171]">
            <p className="text-4xl mb-4">📺</p>
            <p>No videos indexed from this channel yet.</p>
            <p className="text-sm mt-2">Check back soon!</p>
          </div>
        ) : (
          <div className="video-grid">
            {videos.map((v, i) => (
              <VideoCard key={v.youtubeId} video={v} priority={i < 4} />
            ))}
          </div>
        )}

        {/* Back link */}
        <div className="mt-10 pt-6 border-t border-[#3a3a3a]">
          <a href="/" className="text-sm text-[#3ea6ff] hover:underline">← Back to home</a>
        </div>
      </div>
    </>
  );
}
