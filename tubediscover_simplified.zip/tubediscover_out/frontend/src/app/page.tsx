import type { Metadata } from 'next';
import { api, VideoData } from '@/lib/api';
import { VideoCard, VideoCardSkeleton } from '@/components/VideoCard';
import { CategoryPills } from '@/components/CategoryPills';
import { TrendingUp, Clock, Music2, Gamepad2, Tv2, Newspaper } from 'lucide-react';

export const revalidate = 1800; // 30 minutes

export const metadata: Metadata = {
  title: 'TubeDiscover — Discover Trending & Viral YouTube Videos',
  description: 'Discover trending, viral, and hidden YouTube videos. Search millions of videos across music, sports, gaming, news, and more.',
  openGraph: {
    title: 'TubeDiscover — Discover Videos',
    description: 'Find trending and viral YouTube videos across all categories.',
    type: 'website',
  },
};

async function getHomeData() {
  const [trending, recent, music, sports, gaming] = await Promise.allSettled([
    api.trending(undefined, 12),
    api.recent(8),
    api.trending('music', 6),
    api.trending('sports', 6),
    api.trending('gaming', 6),
  ]);

  return {
    trending: trending.status === 'fulfilled' ? trending.value.videos : [],
    recent: recent.status === 'fulfilled' ? recent.value.videos : [],
    music: music.status === 'fulfilled' ? music.value.videos : [],
    sports: sports.status === 'fulfilled' ? sports.value.videos : [],
    gaming: gaming.status === 'fulfilled' ? gaming.value.videos : [],
  };
}

function Section({
  title,
  icon,
  videos,
  href,
  skeletons = 6,
}: {
  title: string;
  icon: React.ReactNode;
  videos: VideoData[];
  href?: string;
  skeletons?: number;
}) {
  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="section-title">
          {icon}
          {title}
        </h2>
        {href && (
          <a href={href} className="text-sm text-[#3ea6ff] hover:underline">
            See all →
          </a>
        )}
      </div>
      {videos.length === 0 ? (
        <div className="video-grid">
          {Array.from({ length: skeletons }).map((_, i) => <VideoCardSkeleton key={i} />)}
        </div>
      ) : (
        <div className="video-grid">
          {videos.map((v, i) => (
            <VideoCard key={v.youtubeId} video={v} priority={i < 4} />
          ))}
        </div>
      )}
    </section>
  );
}

export default async function HomePage() {
  const { trending, recent, music, sports, gaming } = await getHomeData();

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'TubeDiscover',
    url: process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com',
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: `${process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com'}/search/{search_term_string}`,
      },
      'query-input': 'required name=search_term_string',
    },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Category pills */}
        <div className="mb-6">
          <CategoryPills />
        </div>

        {/* Hero / Trending */}
        <Section
          title="Trending Now"
          icon={<TrendingUp size={18} className="text-[#ff0000]" />}
          videos={trending}
          href="/trending"
          skeletons={12}
        />

        {/* Recently Indexed */}
        <Section
          title="Recently Discovered"
          icon={<Clock size={18} className="text-[#3ea6ff]" />}
          videos={recent}
          skeletons={8}
        />

        {/* Music */}
        <Section
          title="Music Videos"
          icon={<Music2 size={18} className="text-purple-400" />}
          videos={music}
          href="/category/music"
          skeletons={6}
        />

        {/* Sports */}
        <Section
          title="Sports Highlights"
          icon={<Tv2 size={18} className="text-green-400" />}
          videos={sports}
          href="/category/sports"
          skeletons={6}
        />

        {/* Gaming */}
        <Section
          title="Gaming"
          icon={<Gamepad2 size={18} className="text-yellow-400" />}
          videos={gaming}
          href="/category/gaming"
          skeletons={6}
        />

        {/* Internal linking */}
        <section className="mt-10 border-t border-[#3a3a3a] pt-8">
          <h2 className="text-[#aaaaaa] text-sm font-medium mb-4">Browse by Category</h2>
          <div className="flex flex-wrap gap-2">
            {['music', 'sports', 'gaming', 'news', 'entertainment', 'tech', 'education', 'lifestyle'].map((cat) => (
              <a
                key={cat}
                href={`/category/${cat}`}
                className="px-4 py-2 bg-[#1e1e1e] border border-[#3a3a3a] rounded-full text-sm hover:bg-[#272727] transition-colors capitalize"
              >
                {cat}
              </a>
            ))}
          </div>
        </section>

        <section className="mt-6">
          <h2 className="text-[#aaaaaa] text-sm font-medium mb-4">Popular Searches</h2>
          <div className="flex flex-wrap gap-2">
            {['music video', 'football highlights', 'movie trailer', 'how to', 'comedy', 'gaming', 'news today', 'tutorial'].map((kw) => (
              <a
                key={kw}
                href={`/search/${encodeURIComponent(kw)}`}
                className="px-4 py-2 bg-[#1e1e1e] border border-[#3a3a3a] rounded-full text-sm hover:bg-[#272727] transition-colors"
              >
                {kw}
              </a>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}
