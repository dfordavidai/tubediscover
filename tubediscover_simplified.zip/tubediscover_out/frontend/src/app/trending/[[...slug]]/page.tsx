import type { Metadata } from 'next';
import { api } from '@/lib/api';
import { VideoCard } from '@/components/VideoCard';
import { CategoryPills } from '@/components/CategoryPills';
import { TrendingUp } from 'lucide-react';

export const revalidate = 900; // 15 minutes

interface Props {
  params: Promise<{ slug?: string[] }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const category = slug?.[0];
  const label = category ? `${category.charAt(0).toUpperCase() + category.slice(1)} ` : '';
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';

  return {
    title: `${label}Trending Videos`,
    description: `Watch the hottest trending ${label.toLowerCase()}videos right now. Updated every hour.`,
    alternates: { canonical: `${siteUrl}/trending${category ? `/${category}` : ''}` },
    openGraph: {
      title: `${label}Trending Videos — TubeDiscover`,
      description: `The hottest ${label.toLowerCase()}videos right now`,
    },
  };
}

export default async function TrendingPage({ params }: Props) {
  const { slug } = await params;
  const category = slug?.[0];

  const { videos } = await api.trending(category, 48).catch(() => ({ videos: [] }));

  const label = category ? category.charAt(0).toUpperCase() + category.slice(1) : 'All';

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="mb-6">
        <CategoryPills active={label} />
      </div>

      <div className="flex items-center gap-3 mb-6">
        <TrendingUp size={24} className="text-[#ff0000]" />
        <div>
          <h1 className="text-2xl font-bold">Trending {label !== 'All' ? label : ''} Videos</h1>
          <p className="text-sm text-[#717171]">Updated hourly based on views and engagement</p>
        </div>
      </div>

      {videos.length === 0 ? (
        <p className="text-[#717171] text-center py-20">No trending videos yet. Check back soon!</p>
      ) : (
        <div className="video-grid">
          {videos.map((v, i) => (
            <VideoCard key={v.youtubeId} video={v} priority={i < 8} />
          ))}
        </div>
      )}

      {/* Trending sub-categories */}
      <section className="mt-10 pt-6 border-t border-[#3a3a3a]">
        <h2 className="text-sm font-medium text-[#aaaaaa] mb-3">Trending by category</h2>
        <div className="flex flex-wrap gap-2">
          {['music', 'sports', 'gaming', 'entertainment', 'news'].map((cat) => (
            <a key={cat} href={`/trending/${cat}`} className={`px-4 py-2 rounded-full text-sm border transition-colors capitalize ${category === cat ? 'bg-[#f1f1f1] text-[#0f0f0f] border-[#f1f1f1]' : 'bg-[#1e1e1e] border-[#3a3a3a] hover:bg-[#272727]'}`}>
              {cat}
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}
