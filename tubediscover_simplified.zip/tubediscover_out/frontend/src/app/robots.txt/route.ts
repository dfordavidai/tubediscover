import { NextResponse } from 'next/server';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';

export function GET() {
  const body = `User-agent: *
Allow: /

# Disallow API routes
Disallow: /api/

# Allow all crawlable pages
Allow: /watch/
Allow: /search/
Allow: /category/
Allow: /trending/
Allow: /channel/

Sitemap: ${SITE_URL}/sitemap.xml
`;

  return new NextResponse(body, {
    headers: {
      'Content-Type': 'text/plain',
      'Cache-Control': 'public, max-age=86400',
    },
  });
}
