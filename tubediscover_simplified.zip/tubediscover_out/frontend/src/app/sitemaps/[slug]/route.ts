import { NextResponse } from 'next/server';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://tubediscover.com';
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

export const revalidate = 3600;

const STATIC_PAGES = [
  { loc: '/', priority: '1.0', changefreq: 'hourly' },
  { loc: '/trending', priority: '0.9', changefreq: 'hourly' },
  { loc: '/trending/music', priority: '0.8', changefreq: 'hourly' },
  { loc: '/trending/sports', priority: '0.8', changefreq: 'hourly' },
  { loc: '/trending/gaming', priority: '0.8', changefreq: 'hourly' },
  { loc: '/trending/news', priority: '0.8', changefreq: 'hourly' },
  { loc: '/trending/entertainment', priority: '0.8', changefreq: 'hourly' },
  { loc: '/category/music', priority: '0.8', changefreq: 'daily' },
  { loc: '/category/sports', priority: '0.8', changefreq: 'daily' },
  { loc: '/category/gaming', priority: '0.8', changefreq: 'daily' },
  { loc: '/category/news', priority: '0.8', changefreq: 'daily' },
  { loc: '/category/entertainment', priority: '0.8', changefreq: 'daily' },
  { loc: '/category/tech', priority: '0.7', changefreq: 'daily' },
  { loc: '/category/education', priority: '0.7', changefreq: 'daily' },
  { loc: '/category/lifestyle', priority: '0.7', changefreq: 'daily' },
  { loc: '/search/music%20video', priority: '0.6', changefreq: 'daily' },
  { loc: '/search/football%20highlights', priority: '0.6', changefreq: 'daily' },
  { loc: '/search/movie%20trailer', priority: '0.6', changefreq: 'daily' },
  { loc: '/search/how%20to', priority: '0.6', changefreq: 'daily' },
  { loc: '/search/gaming', priority: '0.6', changefreq: 'daily' },
  { loc: '/search/news%20today', priority: '0.6', changefreq: 'hourly' },
  { loc: '/search/comedy', priority: '0.6', changefreq: 'daily' },
];

function buildXml(urls: { loc: string; lastmod?: string; changefreq?: string; priority?: string }[]) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">
${urls
  .map(
    (u) => `  <url>
    <loc>${u.loc}</loc>
    ${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}
    ${u.changefreq ? `<changefreq>${u.changefreq}</changefreq>` : ''}
    ${u.priority ? `<priority>${u.priority}</priority>` : ''}
  </url>`
  )
  .join('\n')}
</urlset>`;
}

export async function GET(_req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  // Static pages sitemap
  if (slug === 'static.xml') {
    const urls = STATIC_PAGES.map((p) => ({
      loc: `${SITE_URL}${p.loc}`,
      changefreq: p.changefreq,
      priority: p.priority,
      lastmod: new Date().toISOString().split('T')[0],
    }));
    return new NextResponse(buildXml(urls), {
      headers: { 'Content-Type': 'application/xml', 'Cache-Control': 'public, max-age=3600' },
    });
  }

  // Video sitemaps: videos-0.xml, videos-1.xml ...
  const videoMatch = slug.match(/^videos-(\d+)\.xml$/);
  if (videoMatch) {
    const chunk = videoMatch[1];
    try {
      const res = await fetch(`${API_URL}/api/sitemap/videos/${chunk}`, { next: { revalidate: 3600 } });
      if (!res.ok) throw new Error('not found');
      const data = await res.json();
      const urls = (data.videos || []).map((v: { youtubeId: string; slug?: string; indexedAt: string }) => ({
        loc: `${SITE_URL}/watch/${v.youtubeId}`,
        lastmod: new Date(v.indexedAt).toISOString().split('T')[0],
        changefreq: 'weekly',
        priority: '0.7',
      }));
      return new NextResponse(buildXml(urls), {
        headers: { 'Content-Type': 'application/xml', 'Cache-Control': 'public, max-age=3600' },
      });
    } catch {
      return new NextResponse(buildXml([]), {
        headers: { 'Content-Type': 'application/xml' },
      });
    }
  }

  // Search sitemaps: searches-0.xml, searches-1.xml ...
  const searchMatch = slug.match(/^searches-(\d+)\.xml$/);
  if (searchMatch) {
    const chunk = searchMatch[1];
    try {
      const res = await fetch(`${API_URL}/api/sitemap/searches/${chunk}`, { next: { revalidate: 3600 } });
      if (!res.ok) throw new Error('not found');
      const data = await res.json();
      const urls = (data.keywords || []).map((k: { keyword: string; lastCrawled: string }) => ({
        loc: `${SITE_URL}/search/${encodeURIComponent(k.keyword)}`,
        lastmod: k.lastCrawled ? new Date(k.lastCrawled).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        changefreq: 'daily',
        priority: '0.5',
      }));
      return new NextResponse(buildXml(urls), {
        headers: { 'Content-Type': 'application/xml', 'Cache-Control': 'public, max-age=3600' },
      });
    } catch {
      return new NextResponse(buildXml([]), {
        headers: { 'Content-Type': 'application/xml' },
      });
    }
  }

  return new NextResponse('Not found', { status: 404 });
}
